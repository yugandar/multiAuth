package sribalajiproject.com.multiauth

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.TextView
import android.widget.Toast
import com.kevalpatel2106.fingerprintdialog.AuthenticationCallback
import com.kevalpatel2106.fingerprintdialog.FingerprintDialogBuilder
import com.kevalpatel2106.fingerprintdialog.FingerprintUtils
import kotlinx.android.synthetic.main.activity_main.*
import sribalajiproject.com.multiauth.R.id.textView
import java.lang.Exception

class MainActivity : AppCompatActivity() {
    private var isAuthenticateUsingPin = false
    private var textView: TextView? = null

    val isDeviceSecure: Boolean
        get() {
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN && keyguardManager.isKeyguardSecure

        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = findViewById(R.id.texview) as TextView

        setFingerprintAuthentication()

        if (isAuthenticateUsingPin) {
            startActivity(Intent(this@MainActivity, PinAuthenticationActivity::class.java))
            setFingerprintAuthentication()
        } else {
            showAuthenticationDialog()
        }

    }

    private fun showAuthenticationDialog() {
        FingerprintDialogBuilder(this)
            .setTitle(R.string.fingerprint_dialog_title)
            .setSubtitle(R.string.fingerprint_dialog_subtitle)
            .setDescription(R.string.fingerprint_dialog_description)
            .setNegativeButton(R.string.fingerprint_dialog_button_title)
            .show(supportFragmentManager, object : AuthenticationCallback {
                override fun hasNoFingerprintEnrolled() {
                    // User has no fingerprint enrolled.
                    // Redirecting to the settings.

                    Toast.makeText(this@MainActivity,
                        getString(R.string.error_no_fingerprints_enrolled),
                        Toast.LENGTH_SHORT).show()
                    FingerprintUtils.openSecuritySettings(this@MainActivity)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                    Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()

                    // Unrecoverable error.
                    // Switch to alternate authentication method.
                    setPinAuthentication()
                }

                override fun onAuthenticationHelp(helpCode: Int, helpString: CharSequence?) {
                    // Authentication process has some warning.
                    // Handle it if you want.
                }

                override fun onAuthenticationSucceeded() {
                    // Authentication success
                    // You user is now authenticated.
                    startActivity(Intent(this@MainActivity, AuthenticationSuccessActivity::class.java))
                }

                override fun onAuthenticationFailed() {
                    // Authentication failed.
                    // Fingerprint scanning is still running.
                    val shakeAnim = AnimationUtils.loadAnimation(applicationContext, R.anim.shake)
                    authentication_iv.startAnimation(shakeAnim)
                }

                override fun fingerprintAuthenticationNotSupported() {
                    // Device doesn't support fingerprint authentication.
                    // Switch to alternate authentication method.

                    Toast.makeText(this@MainActivity,
                        getString(R.string.error_fingerprints_not_supported),
                        Toast.LENGTH_SHORT).show()

                    setPinAuthentication()
                    authenticateApp()
                }

                override fun authenticationCanceledByUser() {
                    Toast.makeText(this@MainActivity,
                        getString(R.string.error_auth_canceled_by_user),
                        Toast.LENGTH_SHORT).show()
                }
            })



    }





    private fun setFingerprintAuthentication() {
        isAuthenticateUsingPin = false
    }

    private fun setPinAuthentication() {
        isAuthenticateUsingPin = true
        startActivity(Intent(this@MainActivity, PinAuthenticationActivity::class.java))

    }

    private fun authenticateApp() {
        //Get the instance of KeyGuardManager
        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager

        //Check if the device version is greater than or equal to Lollipop(21)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            //Create an intent to open device screen lock screen to authenticate
            //Pass the Screen Lock screen Title and Description
            val i = keyguardManager.createConfirmDeviceCredentialIntent(resources.getString(R.string.unlock), resources.getString(R.string.confirm_pattern))
            try {
                //Start activity for result
                startActivityForResult(i, LOCK_REQUEST_CODE)
            } catch (e: Exception) {

                //If some exception occurs means Screen lock is not set up please set screen lock
                //Open Security screen directly to enable patter lock
                val intent = Intent(Settings.ACTION_SECURITY_SETTINGS)
                try {

                    //Start activity for result
                    startActivityForResult(intent, SECURITY_SETTING_REQUEST_CODE)
                } catch (ex: Exception) {

                    //If app is unable to find any Security settings then user has to set screen lock manually
                    textView!!.text = resources.getString(R.string.setting_label)
                }

            }

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            LOCK_REQUEST_CODE -> if (resultCode == Activity.RESULT_OK) {
                //If screen lock authentication is success update text
                textView!!.text = resources.getString(R.string.unlock_success)
            } else {
                //If screen lock authentication is failed update text
                textView!!.text = resources.getString(R.string.unlock_failed)
            }
            SECURITY_SETTING_REQUEST_CODE ->
                //When user is enabled Security settings then we don't get any kind of RESULT_OK
                //So we need to check whether device has enabled screen lock or not
                if (isDeviceSecure) {
                    //If screen lock enabled show toast and start intent to authenticate user
                    Toast.makeText(this, resources.getString(R.string.device_is_secure), Toast.LENGTH_SHORT).show()
                    authenticateApp()
                } else {
                    //If screen lock is not enabled just update text
                    textView!!.text = resources.getString(R.string.security_device_cancelled)
                }
        }
    }
    fun authenticateAgain(view: View) {
        authenticateApp()
    }

    companion object {

        private val LOCK_REQUEST_CODE = 221
        private val SECURITY_SETTING_REQUEST_CODE = 233
    }
}
